package com.resultcopy;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class BabyResultDto {

    private Integer childId;
    private String  value;
    private String categoryName;
    private String  resultName;
    private Date dateTime;
}
