package com.resultcopy.service.impl;

import com.resultcopy.CategoryDto;
import com.resultcopy.PatientResultDto;
import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.CategoryDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CategoryDAOImpl implements CategoryDAO {
    public List<CategoryDto> getCategories(){

        PatientResultDto patientResult= null;
        List<CategoryDto> categoryList= new ArrayList<>();
        CategoryDto cd=null;
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT * from Category ";
        System.out.println("SQL :"+sql);
        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                cd=new CategoryDto();
                cd.setId(rs.getInt("CATEGORY_ID"));
                cd.setDisplayName(rs.getString("CATEGORY_NAME"));
                categoryList.add(cd);
            }
            patientResult = new PatientResultDto();
            patientResult.setCategory(categoryList);
        }catch (SQLException ex){
            ex.printStackTrace();
        }

        patientResult.setCategory(categoryList);
        return categoryList;
    }

}
