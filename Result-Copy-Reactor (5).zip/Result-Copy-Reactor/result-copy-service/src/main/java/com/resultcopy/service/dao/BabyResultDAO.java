package com.resultcopy.service.dao;


import com.resultcopy.BabyResultDto;

public interface BabyResultDAO {

    BabyResultDto getBabyPatientByChildId(Integer childId);
    public void createBabyResult(BabyResultDto babyResultDto);
}
