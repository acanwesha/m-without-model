package com.resultcopy.service.dao;


import com.resultcopy.PatientDto;

public interface PatientDAO {

    PatientDto getPatientById(Integer patientId);
}
