package com.resultcopy.service.dao;


import com.resultcopy.PatientDetailsDto;

import java.util.List;

public interface ChildDAO {

    List<PatientDetailsDto> getPatientById(Integer patientId);

}
