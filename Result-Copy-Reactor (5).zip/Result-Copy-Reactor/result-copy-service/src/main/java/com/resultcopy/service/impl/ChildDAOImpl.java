package com.resultcopy.service.impl;

import com.resultcopy.ChildDto;
import com.resultcopy.PatientDetailsDto;
import com.resultcopy.PatientDto;
import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.ChildDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ChildDAOImpl implements ChildDAO {

    @Override
    public List<PatientDetailsDto> getPatientById(Integer patientId) {

        PatientDto patient = null;
        PatientDetailsDto pd = null;
        List<PatientDetailsDto> childDetails = new ArrayList<>();
        ChildDto child = new ChildDto();
        Connection con = ConnectionFactory.getConnection();
        String sql = "SELECT c.child_id ,c.first_name,c.last_name,c.mrn,c.fin FROM patient p ,Child c WHERE p.PATIENT_ID = c.Patient_Id  AND p.PATIENT_ID = "+patientId;
        System.out.println("SQL :"+sql);
        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                pd= new PatientDetailsDto();
                pd.setId(rs.getInt("CHILD_ID"));
                pd.setFirstName(rs.getString("FIRST_NAME"));
                pd.setLastName(rs.getString("LAST_NAME"));
                pd.setMrn(rs.getString("MRN"));
                pd.setFin(rs.getString("FIN"));
                childDetails.add(pd);
            }
            patient = new PatientDto();
            patient.setPatientDetails(pd);

        }catch (SQLException ex){
            ex.printStackTrace();
        }

        child.setChildDetails(childDetails);
        return childDetails;
    }


    public static  void main(String args){
        ChildDAOImpl impl = new ChildDAOImpl();
        impl.getPatientById(1);
    }
}
