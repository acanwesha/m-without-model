package com.resultcopy.service.impl;

import com.resultcopy.BabyResultDto;
import com.resultcopy.service.ConnectionFactory;
import com.resultcopy.service.dao.BabyResultDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BabyResultDAOImpl implements BabyResultDAO {


    @Override
    public BabyResultDto getBabyPatientByChildId(Integer childId) {

        Connection con = ConnectionFactory.getConnection();
        String sql = " SELECT * FROM Baby_Result WHERE CHILD_ID =  "+childId;
        System.out.println("SQL :"+sql);
        BabyResultDto br = null;
        try{
            PreparedStatement pStmt = con.prepareStatement(sql);
            ResultSet rs = pStmt.executeQuery();

            while (rs.next()) {
                br = new BabyResultDto();

                br.setDateTime(rs.getDate("DATE_TIME"));

            }

        }catch (SQLException ex){
            ex.printStackTrace();
        }
        return br;
    }

    @Override
    public void createBabyResult(BabyResultDto babyResultDto) {

        Connection con = ConnectionFactory.getConnection();
        //String sql = " SELECT * FROM Baby_Result WHERE CHILD_ID =  "+childId;
        //System.out.println("SQL :"+sql);

    }
}
